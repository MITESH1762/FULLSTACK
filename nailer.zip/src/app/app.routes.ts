import { Routes } from '@angular/router';
import { AboutComponent } from './components/about/about.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
import { NavigationComponent } from './components/navigation/navigation.component';
import { OurExpertsComponent } from './components/our-experts/our-experts.component';
import { PricingComponent } from './components/pricing/pricing.component';
import { WhatWeDoComponent } from './components/what-we-do/what-we-do.component';
import { GalleryComponent } from './components/gallery/gallery.component'; 
import { LoginComponent } from './components/login/login.component';
export const routes: Routes = [

    {path:'' , component:HeaderComponent},
    {path:'header' , component:HeaderComponent},
    {path:'about' , component:AboutComponent},
    {path:'what-we-do' , component:WhatWeDoComponent},
    {path:'pricing' , component:PricingComponent},
    {path:'our-experts' , component:OurExpertsComponent},
    {path:'gallery' , component:GalleryComponent},
    {path:'contact-us' , component:ContactUsComponent},
    {path:'login' , component:LoginComponent},

       
];
