import { Component } from '@angular/core';

@Component({
  selector: 'app-our-experts',
  standalone: true,
  imports: [],
  templateUrl: './our-experts.component.html',
  styleUrl: './our-experts.component.css'
})
export class OurExpertsComponent {

}
