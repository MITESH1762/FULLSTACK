import { Component } from '@angular/core';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  email: string = '';
  password: string = '';

  login() {
    // const email = document.getElementById('email');
    console.log("email");
    // Here you can perform further actions like sending the data to a server for authentication
  }
}
